﻿using casino;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace SlotMachine
{
    public partial class MainWindow : Window
    {
        private List<List<int>> grid; // Двумерный массив для представления поля слота
        private List<List<int>> winningLines; // Список выигрышных линий
        private decimal balance = 0;

        private List<string> symbols = new List<string>()
        {
            "🍒", "🍋", "🍇", "🔔", "💰"
        };

        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeGrid();
            InitializeWinningLines();
            InitializeGridLayout(); // Добавлено для инициализации разметки сетки
            UpdateGrid();
            UpdateBalance();
            BetAmountComboBox.SelectedIndex = 0;
        }

        private void InitializeGrid()
        {
            grid = new List<List<int>>();
            for (int i = 0; i < 3; i++)
            {
                grid.Add(new List<int>());
                for (int j = 0; j < 5; j++)
                {
                    grid[i].Add(random.Next(symbols.Count)); // Случайно заполняем символами из списка
                }
            }
        }

        private void InitializeWinningLines()
        {
            winningLines = new List<List<int>>();
            winningLines.Add(new List<int>() { 0, 0, 0 }); // Три символа с индексом 0 в первой горизонтальной линии
            winningLines.Add(new List<int>() { 1, 1, 1 }); // Три символа с индексом 1 во второй горизонтальной линии
            winningLines.Add(new List<int>() { 2, 2, 2 });
        }



        private void InitializeGridLayout()
        {
            // Инициализация разметки сетки
            SlotGrid.RowDefinitions.Clear();
            SlotGrid.ColumnDefinitions.Clear();
            SlotGrid.Children.Clear();

            for (int i = 0; i < 3; i++)
            {
                SlotGrid.RowDefinitions.Add(new RowDefinition());
            }

            for (int j = 0; j < 5; j++)
            {
                SlotGrid.ColumnDefinitions.Add(new ColumnDefinition());
            }
        }

        private void AddBalanceClick(object sender, RoutedEventArgs e)
        {
            BalanceInputDialog balanceInputDialog = new BalanceInputDialog();
            if (balanceInputDialog.ShowDialog() == true)
            {
                if (decimal.TryParse(balanceInputDialog.Balance, out decimal amount))
                {
                    if (amount >= 0)
                    {
                        balance += amount;
                        UpdateBalance();
                    }
                    else
                    {
                        MessageBox.Show("Please enter a positive value.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid amount.");
                }
            }
        }

        private void UpdateBalance()
        {
            // Обновляем текстовый блок с балансом
            BalanceText.Text = $"Balance: ${balance}";

        }

        private void SpinButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выбранную ставку
            if (BetAmountComboBox.SelectedItem is ComboBoxItem selectedComboBoxItem && decimal.TryParse(selectedComboBoxItem.Content.ToString(), out decimal betAmount))
            {
                // Проверяем достаточность баланса
                if (balance >= betAmount)
                {
                    // Вычитаем ставку из баланса
                    balance -= betAmount;
                    UpdateBalance();

                    // Генерируем новые символы на поле
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            grid[i][j] = random.Next(symbols.Count);
                        }
                    }

                    // Обновляем отображение символов на поле
                    UpdateGrid();

                    // Проверяем выигрышные линии
                    CheckWinningLines();

                    // Выводим результаты и обновляем баланс
                    UpdateBalance();

                }
                else
                {
                    MessageBox.Show("Insufficient balance. Please add more funds.");
                }
            }
            else
            {
                MessageBox.Show("Please select a valid bet amount.");
            }
        }

        private void UpdateGrid()
        {
            SlotGrid.Children.RemoveRange(0, SlotGrid.Children.Count);
            // Обновляем отображение символов на поле
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    TextBlock symbolTextBlock = new TextBlock();
                    symbolTextBlock.Text = symbols[grid[i][j]];

                    // Добавляем символ на поле в соответствующую позицию сетки
                    Grid.SetRow(symbolTextBlock, i);
                    Grid.SetColumn(symbolTextBlock, j);
                    SlotGrid.Children.Add(symbolTextBlock);
                    
                }
            }
        }

        private void CheckWinningLines()
        {
            foreach (var line in winningLines)
            {
                int symbolIndex = grid[line[0]][0];
                bool isWinningLine = true;
                for (int i = 1; i < line.Count; i++)
                {
                    if (grid[line[i]][i] != symbolIndex)
                    {
                        isWinningLine = false;
                        break;
                        
                    }
                }
                if (isWinningLine)
                {
                    decimal winnings = CalculateWinnings(symbolIndex);
                    balance += winnings;
                }
            }
        }

        private decimal CalculateWinnings(int symbolIndex)
        {
            // Рассчитываем выигрышную сумму в зависимости от символа и ставки
            decimal betMultiplier = 0; // Множитель ставки в зависимости от символа
            switch (symbolIndex)
            {
                // Добавьте провервки для каждого символа и соответствующие множители ставки
                case 0: // Cherry
                    betMultiplier = 2;
                    break;
                case 1: // Lemon
                    betMultiplier = 3;
                    break;
                case 2: // Grapes
                    betMultiplier = 5;
                    break;
                case 3: // Bell
                    betMultiplier = 10;
                    break;
                case 4: // Dollar
                    betMultiplier = 20000;
                    break;
            }
            return betMultiplier * decimal.Parse(((ComboBoxItem)BetAmountComboBox.SelectedItem).Content.ToString());
        }
    }
}